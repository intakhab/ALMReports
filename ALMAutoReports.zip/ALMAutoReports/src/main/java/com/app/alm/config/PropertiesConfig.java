package com.app.alm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/***
 * 
 * @author intakhabalam.s@hcl.com
 * @see Configuration
 * @see PropertySource
 */
@Configuration
@PropertySource("classpath:application.properties")
public class PropertiesConfig {

	@Value("${initial.polling.delay}")
	public String initialPollingDelay;

	public String ipAddress = "";

	public String versionId = "18112018-V-1.0"; // ALM Implemented

}
