package com.app.alm.common;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.app.alm.service.CommonMailService;

/**
 * @author intakhabalam.s@hcl.com
 * @see CommonMailService
 *
 */
public class EmailTemplate {
	private final Logger logger = LogManager.getLogger("Dog-EmailTemplate");

	private String templateId;

	private String template;

	private Map<String, String> replacementParams;
	
    /***
     * Parameterize construction
     * @param templateId {@link String}
     * return {@link EmailTemplate}
     */
	public EmailTemplate(String templateId) {
		this.templateId = templateId;
		try {
			this.template = loadTemplate(templateId);
		} catch (Exception e) {
			this.template = "";
		}
	}
	
	
    /***
     * @see EmailTemplate
     * @param templateId
     * @return
     * @throws Exception
     */
	private String loadTemplate(String templateId) throws Exception {
		File file = Paths.get("templates/" + templateId).toFile();
		createEmailTemplate(file);//check if templates are available or not
		String content = "";
		try {
			content = new String(Files.readAllBytes(file.toPath()));
		} catch (IOException e) {
			throw new Exception("Could not read template with ID = " + templateId);
		}
		return content;
	}
	
	private void createEmailTemplate(File file) {
		if(!file.isDirectory()) {

	        try {
	        	Path path = Paths.get("templates");
	        	logger.info("Email Template Folder is not available creating folder :: "+path.toString());
				Files.createDirectories(path);
				writeFile(HTMLTemplate.emailTemplate(),file.getPath());
				
			} catch (IOException e) {
			}

 		}
	}
	
	/***
	 * Write file
	 * @param data {@link String}
	 * @param filePath {@link String}
	 */
	public void writeFile(String data, String filePath) {
		Path filepath = Paths.get(filePath);
		byte[] bytes = data.getBytes();
		try (OutputStream out = Files.newOutputStream(filepath)) {
			out.write(bytes);
		} catch (Exception e) {
			logger.error("Error: {Com-0015} during writing file {}  ", e);

		}
	}
    /***
     * @param replacements {@link Map}
     * @return {@link String}
     */
	public String getTemplate(Map<String, String> replacements) {
		String cTemplate = this.getTemplate();

		if (!cTemplate.isEmpty()) {
			for (Map.Entry<String, String> entry : replacements.entrySet()) {
				cTemplate = cTemplate.replace("{{" + entry.getKey() + "}}", entry.getValue());
			}
		}
		
		return cTemplate;
	}

	/**
	 * @return the templateId
	 */
	public String getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the template
	 */
	public String getTemplate() {
		return template;
	}

	/**
	 * @param template
	 *            the template to set
	 */
	public void setTemplate(String template) {
		this.template = template;
	}

	/**
	 * @return the replacementParams
	 */
	public Map<String, String> getReplacementParams() {
		return replacementParams;
	}

	/**
	 * @param replacementParams
	 *            the replacementParams to set
	 */
	public void setReplacementParams(Map<String, String> replacementParams) {
		this.replacementParams = replacementParams;
	}

}
