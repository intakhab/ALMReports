package com.app.alm.common;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.app.alm.dto.MailDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * @see MailDto
 */
public class AppUtil {

	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	/***
	 * @param listOfItems {@link List}
	 * @param separator {@link String}
	 * @return {@link String}
	 */
	public static String concatenate(List<String> listOfItems, String separator) {
		StringBuilder sb = new StringBuilder();
		Iterator<String> stit = listOfItems.iterator();

		while (stit.hasNext()) {
			sb.append(stit.next());
			if (stit.hasNext()) {
				sb.append(separator);
			}
		}

		return sb.toString();
	}
	
	
	/**
	 * Checks if is collection empty.
	 * @param collection {@link Collection}
	 * @return {@link Boolean}
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if is object empty.
	 * @param object {@link Object}
	 * @return {@link Boolean}
	 */
	public static boolean isObjectEmpty(Object object) {
		if(object == null) return true;
		else if(object instanceof String) {
			if (((String)object).trim().length() == 0) {
				return true;
			}
		} else if(object instanceof Collection) {
			return isCollectionEmpty((Collection<?>)object);
		}
		return false;
	}
	
	/***
	 * @param fromDate
	 * @return {@link Long}
	 */
	public static long getDateDiff(String fromDate) {
		try {
	       LocalDate dateFrom = LocalDate.parse(fromDate,formatter);
		   LocalDate dateTo = LocalDate.now();
		   // Period intervalPeriod = Period.between(dateFrom, dateTo);
		    long intervalDays = ChronoUnit.DAYS.between(dateFrom, dateTo);
		    return intervalDays;
		    
		}catch (Exception e) {
			return 0;
		}
	}
}
